
The ZIP file contains two versions of the mapping: WITH or WITHOUT bome.
This folder has seperate PDF installation instructions for each version.

----

The BOME version supports jog screens for deck A and B. Pioneer limited this to needle + cue marker. 
This version is more complex to instalation and a license costs 60 eur after testing.

If you need help installing this, please email pedro.estrela@gmail.com.

---
See also the Quick manual PDF; some buttons are mapped differently than rekordbox.


