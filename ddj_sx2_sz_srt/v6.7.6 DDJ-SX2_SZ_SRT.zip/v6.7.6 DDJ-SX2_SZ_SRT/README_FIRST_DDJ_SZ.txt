
The zip file has two versions of the mapping: WITH or WITHOUT bome.

The BOME version is much newer, has new features like All Pad modes in the front, 
dedicated beatjump buttons, and loop adjust with the jog.

This version is the only one getting updates, and updated documentation.

Moving forwrd, BOME will always be required when I port the v7.2 DDJ-1000 to SX2/SZ. 

The Con is that the installation is more complex, and a BOME license costs 60 eur after testing.
If this is an issue, the use the old version instead.


